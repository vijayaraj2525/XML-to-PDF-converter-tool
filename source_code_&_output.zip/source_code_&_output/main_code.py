#!c:/python37/python.exe

import cgi, os
import cgitb; cgitb.enable()
import sys
from PyPDF2 import PdfFileWriter, PdfFileReader
import io
import shutil
import tarfile
import os
import datetime
from datetime import date, datetime
import re
import glob
import os.path
import time
import xml
import lxml
import string
import reportlab.lib.styles
from xml.dom import minidom
import xml.etree.ElementTree as ET
from lxml import etree, objectify
from reportlab.lib import colors
from reportlab.lib.enums import TA_JUSTIFY
from reportlab.lib.pagesizes import letter, A4
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib.units import inch, mm
from reportlab.pdfgen import canvas
from reportlab.platypus import Paragraph, Frame, Spacer, PageBreak, Image, Flowable, Table, TableStyle, \
    SimpleDocTemplate


# GLOBAL VARIABLES
elements=[]
last_modified=''
server_name=''
testname=''
rundate=''

tt1=0
tt2=0
tempp=[]
tempp1=[]
servers = []
cc=[]
testn=[]
testn1=[]
dic=[]
dic1=[]
section2_4=[]
services=[]
x=0
img=True
elements = []
dict_third_part={}
styles = getSampleStyleSheet()
styleP = styles["Normal"]
styleH = styles["Heading4"]
styleP.fontSize = 10
styleH.alignment = 1

fn=''
pfname=''
#country=''
#project=''
with open('kbref.txt','r') as kb:
   kbr=kb.readlines()
def getfile():
   global fn
   #global country
   #global project
   form = cgi.FieldStorage()

   print("Content-type: text/html\r\n\r\n")  
   print("<html><body bgcolor='lightblue'>")
   print("<meta http-equiv='refresh' content='100; URL=http://10.203.28.211:8052/code_files/login_page.php'>")
   # Get filename here.
   fileitem = form['filename']
   '''if form.getvalue('country'):
      country = form.getvalue('country')
   if form.getvalue('project'):
      project = form.getvalue('project')
   '''
   # Test if the file was uploaded
   if fileitem.filename:
      # strip leading path from file name to avoid 
      # directory traversal attacks
      fn = os.path.basename(fileitem.filename)
      
      if fn.endswith(".tgz"):
         open(fn, 'wb').write(fileitem.file.read())
         #open(fileitem.filename, 'wb').write(fileitem.file.read())
         message = 'The file ' + fn + ' was uploaded successfully'
      else:
         print("<br /><br /><p align=center> <font color=red size=10>please upload .tgz format file</font></p>")
         print("<br /><p align=center><font size=5>go back and try again</font></p>")
         print("<br /><p align=center><font size=3><a href=http://10.203.28.211:8052/code_files/upload_profile.php>click here to go back<a/></font></p>")
         sys.exit(0)
   else:
      message = 'No file was uploaded'
      print("<br /><br /><p align=center><font color=red size=7>%s</font></p>" % message)
      print("<br /><p align=center><font size=5>go back and try again</font></p>")
      print("<br /><p align=center><font size=3><a href=http://10.203.28.211:8052/code_files/upload_profile.php>click here to go back<a/></font></p>")
      sys.exit(0)
      
   print("<br /><br /><p align=center><font color=blue size=5>%s</font></p>" % message)


class Img2Sec_6:
   ''' from image, index page sec 2,3,4,.. to 6 '''
   def img2intro(self):
      global pfname
      #global country
      #global project
      sam=[]
      im=Image('altran.png',1.95*inch,0.68*inch)
      im.hAlign='RIGHT'
      sam.append(im)
      im=Image('altran_old.jpg',8*inch,6.25*inch)
      sam.append(im)
      sam.append(Spacer(1,0.15*inch))
      text='<para alignment=left><font size=16><b>Nokia 8690 Open Service Platform</b><br /><br /></font></para>'
      sam.append(Paragraph(text,styles['Normal']))
      sam.append(Spacer(1,0.15*inch))
      text='<para alignment=left><font size=14>ALANIS AUDIT REPORT</font></para>'
      sam.append(Paragraph(text,styles['Normal']))
      sam.append(Spacer(1,0.15*inch))
      #pfname=''
      okn=fn
      #print(okn)
      for i in okn:
         if i.isalpha() or i=='_':
            pfname+=i
         if i.isdigit():
            break
      pfname=pfname[0:-1]
      sam.append(Paragraph('<para> <font textcolor=green>%s</font></para>'%pfname,styleP))
      '''if country!='' and project!='':
         counpro=country.title()+"_"+project.upper()
      elif country!='' or project!='':
         if country=='':
            counpro=project.upper()
         else:
            counpro=country.title()
      else:
         counpro=" "
      '''
      #sam.append(Paragraph('<para> <font textcolor=green>%s</font></para>'%(counpro),styleP))
      sam.append(Paragraph('''<font size=10 textcolor=green>Profile : </font>'''+pfname.split('_')[-1] ,styleP))
      rd='''<font size=10 textcolor=green>Report Date : </font>'''+rundate
      sam.append(Paragraph(rd,styles['Normal']))
      

      text='<para alignment=left><font size=10><br /><br /> NOKIA PROPRIETARY<br /></font></para>'
      sam.append(Paragraph(text,styles['Normal']))
      text='<para alignment=left><font size=10>This document contains proprietary information of NOKIA and is not to be disclosed or used except in accordance with applicable agreements</font></para>'
      sam.append(Paragraph(text,styles["Normal"]))
      sam.append(PageBreak()) 
      ptext='<para alignment=center><font size=12><b>PREFACE</b></font></para>'
      sam.append(Paragraph(ptext,styles['Normal']))
      sam.append(Spacer(1,0.2*inch))
      ptext='<para alignment=left><font size=10>This document provides the main steps of one platform Alanis audit reports.</font></para>'
      sam.append(Paragraph(ptext,styles['Normal']))
      sam.append(Spacer(1,0.2*inch))
      ptext='<para alignment=center><font size=12><b>HISTORY</b><br /><br /><br /></font></para>'
      sam.append(Paragraph(ptext,styles['Normal']))
      data = []
      data.append([Paragraph('<para alignment=center>Edition</para>', styleP), Paragraph('<para alignment=center>Date</para>', styleP),Paragraph('<para alignment=center>Comments</para>', styleP)])
      today=date.today()
      data.append([Paragraph(' Ed 01', styleP), Paragraph(today.strftime("%b %d, %Y"), styleP),Paragraph('Creation of document', styleP)])	
      t5 = Table(data, 2.7 * inch)
      t5.setStyle(TableStyle([
               ('ALIGN', (0, 1), (-1, -1), 'LEFT'),
               ('BOX', (0, 0), (-1, -1), 0.5, colors.black),
               ('FONTSIZE', (0, 0), (-1, -1), 10),
               ('GRID', (0, 0), (-1, -1), 0.5, colors.black),
               ('BACKGROUND', (0, 0), (-1, 0), colors.lightskyblue),
               ]))
      sam.append(t5)            
      sam.append(Spacer(1,0.2*inch))
      ptext='<para alignment=center><br /><font size=12><b>TABLE OF CONTENTS</b><br /></font></para>'
      sam.append(Paragraph(ptext,styles['Normal']))
      sam.append(Spacer(1,0.2*inch))
      line1='<para alignment=left><font size=10><b><a href="#index0"><a name="reindex0" />1 INTRODUCTION</a></b></font><br /><br /></para>'
      line2='<para alignment=left><font size=10><b><a href="#index1"><a name="reindex1" />2 ALANIS POINTS TO CHECK</a></b></font><br /><br /></para>'
      line3='<para alignment=left leftIndent=15><font size=10>   2.1 UNAVAILABLE SERVERS</font></para>'
      line4='<para alignment=left leftIndent=15><font size=10>   2.2 TEST INC</font></para>'
      line5='<para alignment=left leftIndent=15><font size=10>   2.3 TEST WG</font></para>'
      line6='<para alignment=left leftIndent=15><font size=10>   2.4 SYNTHESIS</font><br /><br /></para>'
      line7='<para alignment=left><font size=10><b><a href="#index2"><a name="reindex2" />3 ALANIS CHECKS OK</a></b></font><br /><br /></para>'
      line8='<para alignment=left><font size=10><b><a href="#index3"><a name="reindex3" />4 APPLICATION POINTS TO CHECK</a></b></font><br /><br /></para>'
      line9='<para alignment=left leftIndent=15><font size=10>   4.1 TESTS LIST</font></para>'
      line10='<para alignment=left leftIndent=15><font size=10>   4.2 TESTS OK</font></para>'
      line11='<para alignment=left leftIndent=15><font size=10>   4.3 TESTS WG</font><br /><br /></para>'
      line12='<para alignment=left><font size=10><b><a href="#index4"><a name="reindex4" />5 APLLICATION ARCHITECTURE</a></b></font><br /><br /></para>'
      line13='<para alignment=left leftIndent=15><font size=10>   5.1 HARDWARE ARCHITECTURE</font></para>'
      line14='<para alignment=left leftIndent=15><font size=10>   5.2 SOFTWARE ARCHITECTURE</font><br /><br /></para>'
      line15='<para alignment=left leftIndent=15><font size=10><b>   <a href="#index4.1"><a name="reindex4.1" />5.3 SERVICES CONFIGURATION</a></b></font><br /><br /></para>'
      line16='<para alignment=left leftIndent=35><font size=10>      5.3.1 SERVERS HOSTING EACH SLEE PARTITION</font></para>'
      line17='<para alignment=left leftIndent=35><font size=10>      5.3.2 SLEE PARTITIONS HOSTED BY EACH SERVER</font></para>'
      line18='<para alignment=left leftIndent=35><font size=10>      5.3.3 SMFS HOSTING EACH SMF PARTITION</font></para>'
      line19='<para alignment=left leftIndent=35><font size=10>      5.3.4 SMF PARTITIONS HOSTING BY EACH SMF</font><br /><br /></para>'
      line20='<para alignment=left leftIndent=15><font size=10>   5.4 APPLICATION ARCHITECTURE CONCLUSION</font><br /><br /></para>'
      line21='<para alignment=left><font size=10><b><a href="#index5"><a name="reindex5" />6 GENERAL ALANIS CONCLUSION</a></b><br></br></font><br /></para>'
      line22='<para alignment=left><font size=10><b><a href="#index6"><a name="reindex6" />7 ANNEXE 1 (INC TESTS)</a></b></font><br /><br /></para>'                                          
      line23='<para alignment=left><font size=10><b><a href="#index7"><a name="reindex7" />8 ANNEXE 2 (WARNING TESTS)</a></b></font><br /><br /></para>'
      sam.append(Paragraph(line1,styles["Normal"]))
      sam.append(Paragraph(line2,styles["Normal"]))
      sam.append(Paragraph(line3,styles["Normal"]))
      sam.append(Paragraph(line4,styles["Normal"]))
      sam.append(Paragraph(line5,styles["Normal"]))
      sam.append(Paragraph(line6,styles["Normal"]))
      sam.append(Paragraph(line7,styles["Normal"]))
      sam.append(Paragraph(line8,styles["Normal"]))
      sam.append(Paragraph(line9,styles["Normal"]))
      sam.append(Paragraph(line10,styles["Normal"]))
      sam.append(Paragraph(line11,styles["Normal"]))
      sam.append(Paragraph(line12,styles["Normal"]))
      sam.append(Paragraph(line13,styles["Normal"]))
      sam.append(Paragraph(line14,styles["Normal"]))
      sam.append(Paragraph(line15,styles["Normal"]))
      sam.append(Paragraph(line16,styles["Normal"]))
      sam.append(Paragraph(line17,styles["Normal"]))
      sam.append(Paragraph(line18,styles["Normal"]))
      sam.append(Paragraph(line19,styles["Normal"]))
      sam.append(Paragraph(line20,styles["Normal"]))
      sam.append(Paragraph(line21,styles["Normal"]))
      sam.append(Paragraph(line22,styles["Normal"]))
      sam.append(Paragraph(line23,styles["Normal"]))
      sam.append(PageBreak())
      ptext='<para alignment=center><font size=12><b>REFERENCE DOCUMENTS</b><br /><br /></font></para>'
      sam.append(Paragraph(ptext,styles['Normal']))
      data = []
      data.append([Paragraph('<para alignment=center> Num</para>', styleP), Paragraph('<para alignment=center>Reference</para>', styleP),Paragraph('<para alignment=center>Ed</para>', styleP),Paragraph('Title', styleP)])
      data.append(["","","",""])	
      t6 = Table(data, 2.025 * inch)
      t6.setStyle(TableStyle([
               ('ALIGN', (0, 1), (-1, -1), 'LEFT'),
               ('BOX', (0, 0), (-1, -1), 0.5, colors.black),
               ('GRID', (0, 0), (-1, -1), 0.5, colors.black),
               ('BACKGROUND', (0, 0), (-1, 0), colors.lightskyblue),
               ]))
      sam.append(t6)
      sam.append(Spacer(1,0.2*inch))
      sam.append(PageBreak())
      ptext='<para alignment=center><font size=12><br /><b><a href="#reindex0"><a name="index0" />1 INTRODUCTION</a></b></font></para>'
      sam.append(Paragraph(ptext,styles['Normal']))
      sam.append(Spacer(1,0.2*inch))
      ptext='<para alignment=center><font size=10 textcolor=red>SOME FREE TEXT ITEM in order to introduce the aim of this audit report, customer context, some generic introduction.</font></para>'
      sam.append(Paragraph(ptext,styles['Normal']))
      sam.append(PageBreak()) 
      # section-2
      P = Paragraph('''
               <para align='center' fontSize=12><br /><b><a href="#reindex1"><a name="index1" />
               2 ALANIS POINTS TO CHECK</a></b><br /><br /></para>''',
               styles["Normal"])
      # section-2.1
      P2 = Paragraph('''
               <para align='left' fontSize=12><b>
               2.1 UNAVAILABLE SERVERS</b><br /><br /></para>''',
               styles["Normal"])
      sam.append(P)
      sam.append(P2)
      return sam
   def sec2_24(self):
      '''fetcing data for section 2.1, 2.2, 2.3, 2.4 '''
      temp=[] # for returning purpose
      data=[]
      data.append([Paragraph("<para align='center'>HostName</para>", styleP),Paragraph("<para align='center'>FunctionServer</para>", styleP)])
      data.append(["",""])
      t1=Table(data, 4.05*inch)
      t1.setStyle(TableStyle([
                  ('ALIGN', (0, 0), (-1, -1), 'CENTER'),
                  ('BOX', (0,0), (-1,-1), 0.25, colors.black),
                  ('INNERGRID', (0,0), (-1,-1), 0.25, colors.black),
                  ('FONTSIZE', (0, 2), (-1,-1), 6),
                  ('BACKGROUND', (0, 0), (-1, 0), colors.lightskyblue)
                  ]))
      temp.append(t1)
      # section-2.2
      data=[]
      P1 = Paragraph('''
                  <para align=left fontSize=12><br /><b>
                  2.2 TEST INC</b><br /><br /></para>''',
                  styles["Normal"])
      data.append([Paragraph("<para align='center'>CheckName</para>", styleP),Paragraph("<para align='center'>Criticity</para>", styleP),Paragraph("<para align='center'>KbRef</para>", styleP),Paragraph("<para align='center'>Impacted_servers</para>", styleP)])
      testn2=set(testn)
      testn2=list(testn2)
      testn2.sort()
      nn=[]
      impact=[]
      cric=""
      kbva=""
      tt=0
      for i in testn2:
         for j in dic1:
            if i == j[0]:
               cric=j[1]
               kbva=j[2]
               nn.append(j[3])
         listToStr = '; '.join(map(str, nn))
         im=Paragraph(listToStr,styleP)
         val="#link"+str(tt)
         check=Paragraph('<para> <a href=%s color="blue"><a name=%s /><u>%s</u></a></para>'%(val,val[1:]+"1",i),styleP)
         cri=Paragraph("<para align='center'>%s</para>"%cric,styleP)
         kbv=Paragraph(kbva,styleP)
         impact.append([check,cri,kbv,im])
         nn=[]
         tt=tt+1
      for i in impact:
         data.append(i)
      t2=Table(data)
      t2.setStyle(TableStyle([
                  ('ALIGN', (0, 0), (-1,0), 'CENTER'),
                  ('ALIGN', (0, 2), (-1,-1), 'LEFT'),
                  ('FONTSIZE', (0, 0), (-1,-1), 6),
                  ('BOX', (0,0), (-1,-1), 0.25, colors.black),
                  ('INNERGRID', (0,0), (-1,-1), 0.25, colors.black),
                  ('BACKGROUND', (0, 0), (-1, 0), colors.lightskyblue)
                  ]))
      t2._argW[0]=2.1*inch
      t2._argW[1]=0.9*inch
      t2._argW[2]=0.9*inch
      t2._argW[3]=4.225*inch
      temp.append(P1)
      temp.append(t2)
      #section - 2.3
      P4=Paragraph('''
                  <para align='left' fontSize=12><br /><b>
                  2.3 TEST WG</b><br /><br /></para>''',
                  styles["Normal"])
      data=[]
      data.append([Paragraph("<para align='center'>CheckName</para>", styleP),Paragraph("<para align='center'>Criticity</para>", styleP),Paragraph("<para align='center'>KbRef</para>", styleP),Paragraph("<para align='center'>Impacted_servers</para>", styleP)])
      testn3=set(testn1)
      testn3=list(testn3)
      testn3.sort()
      nn=[]
      impact=[]
      cric=""
      kbva=""
      for i in testn3:
         for j in dic:
            if i == j[0]:
               cric=j[1]
               kbva=j[2]
               nn.append(j[3])
         listToStr = '; '.join(map(str, nn))
         im=Paragraph(listToStr,styleP)
         val="#link"+str(tt)
         check=Paragraph('<para> <a href=%s color="blue"><u><a name=%s />%s</u></a></para>'%(val, val[1:]+"1", i),styleP)
         cri=Paragraph(cric,styleP)
         kbv=Paragraph(kbva,styleP)
         impact.append([check,cri,kbv,im])
         nn=[]
         tt=tt+1
      for i in impact:
         data.append(i)
      t4=Table(data)
      t4.setStyle(TableStyle([
                  ('ALIGN', (0, 0), (-1,0), 'CENTER'),
                  ('ALIGN', (0, 1), (-1,-1), 'LEFT'),
                  ('FONTSIZE', (0, 0), (-1,-1), 6),
                  ('BOX', (0,0), (-1,-1), 0.25, colors.black),
                  ('INNERGRID', (0,0), (-1,-1), 0.25, colors.black),
                  ('BACKGROUND', (0, 0), (-1, 0), colors.lightskyblue)
                  ]))
      t4._argW[0]=2.1*inch
      t4._argW[1]=0.9*inch
      t4._argW[2]=0.9*inch
      t4._argW[3]=4.225*inch
      temp.append(P4)
      temp.append(t4)
      #section- 2.4
      P7 = Paragraph('''
                  <para align=left fontSize=12><br /><b>
                  2.4 SYNTHESIS</b><br /><br /></para>''',
                  styles["Normal"])
      temp9=[]
      temp10=[]
      data = []
      ffp1=open("section2_4.txt",'r',encoding="utf8")
      ffp=ffp1.readlines()
      data.append([Paragraph('Test_Name', styleP), Paragraph('Comments', styleP)])
      for i in testn2:
         for j in section2_4:
            if i==j[0]:
               
               temp10.append(j[1])
              
               break
           
      if pfname.split('_')[-1]=="default":
         
         for i in temp10:
            co=""
            for j in ffp[1:]:
               
               foun=j.find("ALANIS ORACLE PROFILE")
               
               if foun!=-1:
                  break
               foun1=j.split("=")
               
               if foun1[0].strip()==i.strip():
                  
                  co = foun1[1].strip()
                  break
           
            temp9.append([i.strip(),co])
            
      elif pfname.split('_')[-1]=="oracle":
        
         n=0
         for j in ffp:
           
            foun=j.find("ALANIS ORACLE PROFILE")
            n=n+1
            if foun!=-1:
               break
         for i in temp10:
          
            co=""
            
            for j in ffp[n+1:]:
               foun1=j.split("=")
               
               if foun1[0].strip()==i.strip():
                 
                  co = foun1[1].strip()
                  break
            
            temp9.append([i.strip(),co])
            
      ffp1.close()
     
      for i in temp9:
         data.append([Paragraph(i[0], styleP),Paragraph(i[1], styleP)])
      t7 = Table(data)
      t7.setStyle(TableStyle([
                  ('ALIGN', (0, 0), (-1, 0), 'CENTER'),
                  ('ALIGN', (0, 1), (-1, -1), 'LEFT'),
                  ('BOX', (0, 0), (-1, -1), 0.5, colors.black),
                  ('FONTSIZE', (0, 0), (-1, -1), 6),
                  ('GRID', (0, 0), (2, -1), 0.5, colors.black),
                  ('BACKGROUND', (0, 0), (-1, 0), colors.lightskyblue),
                  ]))
      t7._argW[0]=3*inch
      t7._argW[1]=5.1*inch
      temp.append(P7)
      temp.append(t7)
      return temp
   def sec_3(self):
      ''' fetching data for section 3, ALANIS CHECKS OK '''
      temp=[]
      P3 = Paragraph('''
                  <para align=center fontSize=10><br /><b><a href="#reindex2"><a name="index2" />
                  3 ALANIS CHECKS OK</a></b><br /><br /></para>''',
                  styles["Normal"])
      data = []
      data.append([Paragraph('CheckName', styleP), Paragraph('OK_hosts', styleP)])
      for key, value in (dict_third_part).items():
         key = Paragraph(str(key), styleP)
         val = Paragraph("; ".join([str(i) for i in value]), styleP)
         data.append([key, val])
      t3 = Table(data,4.05*inch)#, 3.25 * inch)
      t3.setStyle(TableStyle([
                  ('ALIGN', (0, 0), (-1, 0), 'CENTER'),
                  ('ALIGN', (0, 1), (-1, -1), 'LEFT'),
                  ('BOX', (0, 0), (-1, -1), 0.5, colors.black),
                  ('FONTSIZE', (0, 0), (-1, -1), 6),
                  ('GRID', (0, 0), (2, -1), 0.5, colors.black),
                  ('BACKGROUND', (0, 0), (-1, 0), colors.lightskyblue),
                  ]))
      temp.append(P3)
      temp.append(t3)
      return temp
      
   def sec4_43(self):
      '''fetching data for section 4.1, 4.2, 4.3 '''
      temp=[]
      #print(pfname)
      if pfname.split('_')[-1]=="default":
         data=[]
         P_1 = Paragraph('''<para align='center' fontSize=12><br /><b><a href="#reindex3"><a name="index3" />4 APPLICATION POINTS TO CHECK</a></b><br /></para>''',styles["Normal"])
         P_2 = Paragraph('''<para align='left' fontSize=12><br /><b>4.1 TESTS LIST</b><br /><br /></para>''',styles["Normal"])
         P_3 = Paragraph('''<para align='left' fontSize=10>post dblink</para>''',styles["Normal"])
         P_4 = Paragraph('''<para align='left' fontSize=10>Collect OspSurvey data and put in right place</para>''',styles["Normal"])
         P_5 = Paragraph('''<para align='left' fontSize=10>Verify the Hosts File on all servers</para>''',styles["Normal"])
         data.append([Paragraph("<para align='center'>TestName</para>", styleP),Paragraph("<para align='center'>Comments</para>", styleP)])
         data.append([P_3,""])
         data.append([P_4,""])
         data.append([P_5,""])
         fourt1=Table(data, 4.05*inch)
         fourt1.setStyle(TableStyle([
                  ('ALIGN', (0, 0), (-1, -1), 'CENTER'),
                  ('BOX', (0,0), (-1,-1), 0.25, colors.black),
                  ('INNERGRID', (0,0), (-1,-1), 0.25, colors.black),
                  ('FONTSIZE', (0, 2), (-1,-1), 10),
                  ('BACKGROUND', (0, 0), (-1, 0), colors.lightskyblue)
                  ]))
         #  section 4.2
         data=[]
         P_22 = Paragraph('''<para align='left' fontSize=12><br /><b>4.2 TESTS OK</b><br /><br /></para>''',styles["Normal"])
         P_33 = Paragraph('''<para align='left' fontSize=10>collect mrtg results if configured</para>''',styles["Normal"])
         P_44 = Paragraph('''<para align='left' fontSize=10>Ctrl Files are identical on cluster</para>''',styles["Normal"])
         P_55 = Paragraph('''<para align='left' fontSize=10>lists Error by servers</para>''',styles["Normal"])
         P_66 = Paragraph('''<para align='left' fontSize=10>Verify file size and right of pfmconfig.dump, before and after runScript</para>''',styles["Normal"])
         P_77 = Paragraph('''<para align='left' fontSize=10>Verify the Week of all servers</para>''',styles["Normal"])
         P_88 = Paragraph('''<para align='left' fontSize=10>Collect Ss7Survey Data and put it in the right place</para>''',styles["Normal"])                                    
         data.append([Paragraph("<para align='center'>TestName</para>", styleP),Paragraph("<para align='center'>Comments</para>", styleP)])
         data.append([P_33,""])
         data.append([P_44,""])
         data.append([P_55,""])
         data.append([P_66,""])
         data.append([P_77,""])
         data.append([P_88,""]) 
         fourt2=Table(data, 4.05*inch)
         fourt2.setStyle(TableStyle([
                  ('ALIGN', (0, 0), (-1, -1), 'CENTER'),
                  ('BOX', (0,0), (-1,-1), 0.25, colors.black),
                  ('INNERGRID', (0,0), (-1,-1), 0.25, colors.black),
                  ('FONTSIZE', (0, 2), (-1,-1), 10),
                  ('BACKGROUND', (0, 0), (-1, 0), colors.lightskyblue)
                  ]))         
         # section 4.3
         data=[]
         P_31 = Paragraph('''<para align='left' fontSize=12><br /><b>4.3 TESTS WG</b><br /><br /></para>''',styles["Normal"])                                    
         data.append([Paragraph("<para align='center'>TestName</para>", styleP),Paragraph("<para align='center'>Comments</para>", styleP)])
         data.append(["",""])
         fourt3=Table(data, 4.05*inch)
         fourt3.setStyle(TableStyle([
                  ('ALIGN', (0, 0), (-1, -1), 'CENTER'),
                  ('BOX', (0,0), (-1,-1), 0.25, colors.black),
                  ('INNERGRID', (0,0), (-1,-1), 0.25, colors.black),
                  ('FONTSIZE', (0, 2), (-1,-1), 10),
                  ('BACKGROUND', (0, 0), (-1, 0), colors.lightskyblue)
                  ]))
         temp.append(P_1)
         temp.append(P_2)
         temp.append(fourt1)
         temp.append(P_22)
         temp.append(fourt2)
         temp.append(P_31)
         temp.append(fourt3)
      else:
         data=[]
         P_1 = Paragraph('''<para align='center' fontSize=12><br /><b><a href="#reindex3"><a name="index3" />4 APPLICATION POINTS TO CHECK</a></b><br /></para>''',styles["Normal"])
         P_2 = Paragraph('''<para align='left' fontSize=12><br /><b>4.1 TESTS LIST</b><br /><br /></para>''',styles["Normal"])
         P_3 = Paragraph('''<para align='left' fontSize=10>post check for Oracle Objects</para>''',styles["Normal"])
         data.append([Paragraph("<para align='center'>TestName</para>", styleP),Paragraph("<para align='center'>Comments</para>", styleP)])
         data.append([P_3,""])
         fourt1=Table(data, 4.05*inch)
         fourt1.setStyle(TableStyle([
                  ('ALIGN', (0, 0), (-1, -1), 'CENTER'),
                  ('BOX', (0,0), (-1,-1), 0.25, colors.black),
                  ('INNERGRID', (0,0), (-1,-1), 0.25, colors.black),
                  ('FONTSIZE', (0, 2), (-1,-1), 10),
                  ('BACKGROUND', (0, 0), (-1, 0), colors.lightskyblue)
                  ]))
         #  section 4.2
         data=[]
         P_22 = Paragraph('''<para align='left' fontSize=12><br /><b>4.2 TESTS OK</b><br /><br /></para>''',styles["Normal"])
         P_33 = Paragraph('''<para align='left' fontSize=10>post check for Oracle Tables consistancy</para>''',styles["Normal"])
         P_44 = Paragraph('''<para align='left' fontSize=10>post  check the content of the dsc-files</para>''',styles["Normal"])
         P_66 = Paragraph('''<para align='left' fontSize=10>Verify file size and right of pfmconfig.dump, before and after runScript</para>''',styles["Normal"])
         data.append([Paragraph("<para align='center'>TestName</para>", styleP),Paragraph("<para align='center'>Comments</para>", styleP)])
         data.append([P_33,""])
         data.append([P_44,""])
         data.append([P_66,""])
         fourt2=Table(data, 4.05*inch)
         fourt2.setStyle(TableStyle([
                  ('ALIGN', (0, 0), (-1, -1), 'CENTER'),
                  ('BOX', (0,0), (-1,-1), 0.25, colors.black),
                  ('INNERGRID', (0,0), (-1,-1), 0.25, colors.black),
                  ('FONTSIZE', (0, 2), (-1,-1), 10),
                  ('BACKGROUND', (0, 0), (-1, 0), colors.lightskyblue)
                  ]))
         # section 4.3
         data=[]
         P_31 = Paragraph('''<para align='left' fontSize=12><br /><b>4.3 TESTS WG</b><br /><br /></para>''',styles["Normal"])                                    
         data.append([Paragraph("<para align='center'>TestName</para>", styleP),Paragraph("<para align='center'>Comments</para>", styleP)])
         data.append([Paragraph('''<para align='left' fontSize=10>post Oracle config init.ora is the same between SMFs and mated pair SMFs</para>''',styleP),""])
         fourt3=Table(data, 4.05*inch)
         fourt3.setStyle(TableStyle([
                  ('ALIGN', (0, 0), (-1, -1), 'CENTER'),
                  ('BOX', (0,0), (-1,-1), 0.25, colors.black),
                  ('INNERGRID', (0,0), (-1,-1), 0.25, colors.black),
                  ('FONTSIZE', (0, 2), (-1,-1), 10),
                  ('BACKGROUND', (0, 0), (-1, 0), colors.lightskyblue)
                  ]))
         temp.append(P_1)
         temp.append(P_2)
         temp.append(fourt1)
         temp.append(P_22)
         temp.append(fourt2)
         temp.append(P_31)
         temp.append(fourt3)
      return temp
         
   def sec5_54_6(self):
      ''' fetching the data for section 5.1, 5.2 , 5.3.1 to 5.3.4 , 5.4'''
      #section 5.1 and 5.2
      tempy=[]
      
      sec5_1=[]
      sec5_2=[]
      #local variables
      filenames = ''
      count=0
      for server in servers:
         se1=se2=se3=se4=se5=se6=se7=se8=se9=se10=se11=se12=se13=" "
         for file in \
            glob.glob('./result/servers/{0}/*.xml'.format(server)):
            filenames = filenames + '\n' + file
            testname = file.rsplit('\\', 1)[1].replace('.pl.xml', '')
            file_content = open(file, 'r')
            obj = 'obj' + str(count)
            obj = Annex_78(file)
            xml = obj.xml_obj
            for child in xml.iterchildren():
               if child.get("name")=="Hostname":
                  se1=child.text
               if child.get("name")=="HostType":
                  se2=child.text
               if child.get("name")=="FunctionServer":
                  se3=child.text
               if child.get("name")=="CpuNumber":
                  se4=child.text
               if child.get("name")=="CpuSpeed":
                  se5=child.text
               if child.get("name")=="SN":
                  se6=child.text
               if child.get("name")=="MemorySize":
                  se7=child.text
               if child.get("name")=="MachType":
                  se8=child.text
               # below are for section 5.2
               if child.get("name")=="OsLevel":
                  se9=child.text
               if child.get("name")=="OsType":
                  se10=child.text
               if child.get("name")=="Ss7StackVersion":
                  se11=child.text
               if child.get("name")=="OracleVersion":
                  se12=child.text
               if child.get("name")=="OspWeekLevel":
                  se13=child.text
            if se13==None:
               se13=" "
            if se1==None:
               se1=" "
            if se2==None:
               se2==" "
            if se3==None:
               se3=" "
            if se4==None:
               se4=" "
            if se5==None:
               se5=" "
            if se6==None:
               se6=" "
            if se7==None:
               se7=" "
            if se8==None:
               se8=" "
            if se9==None:
               se9=" "
            if se10==None:
               se10=" "
            if se11==None:
               se11=" "
            if se12==None:
               se12=" "
            if (se1!=' ' or se2!=' ' or se3!=' ' or se4!=' ' or se5!=' ' or se6!=' ' or se7!=' ' or se8!=' ' ): # server or se1
               sec5_1.append([Paragraph(server, styleP),Paragraph(se2, styleP),Paragraph(se3, styleP), \
                           Paragraph(se4, styleP),Paragraph(se5, styleP),Paragraph(se6, styleP), \
                              Paragraph(se7, styleP),Paragraph(se8, styleP)])
            if (se1!=' ' or se9!=' ' or se10!=' ' or se11!=' ' or se12!=' ' or se13!=' '):
               sec5_2.append([Paragraph(se1, styleP),Paragraph(se9, styleP),Paragraph(se10, styleP), \
                           Paragraph(se11, styleP),Paragraph(se12, styleP),Paragraph(se13[1:], styleP)])
            count=count+1
      #section 5.3.1 , 5.3.3 , 5.3.4
               
      #for section 5.3
      tree1 = ET.parse('./result/services/alanisOspServices.xml')
      root1 = tree1.getroot()
      for child in root1:
         services.append(child.text)
      count=0
      sec5_3=[]
      sec5_3_3=[]
      sec5_3_4=[]
      smf_list=[]
      for service in services:
         se1=" "
         host=[]
         serv=[]
         smf=[]
         part=[]
         temp1=[]
         temp2=[]
         flag=False
         for file in \
             glob.glob('./result/services/{0}/*.xml'.format(service)):
             filenames = filenames + '\n' + file
             service_name = file.split('/')[3]
             testname = file.rsplit('\\', 1)[1].replace('.pl.xml', '')
             file_content = open(file, 'r')
             obj = 'obj' + str(count)
             obj = Annex_78(file)
             xml = obj.xml_obj
             point1=0
             point2=0
             for child in xml.iterchildren(): 
                # below are for section 5.3
                abc=child.text
                if (abc!= None) and (abc in servers):
                   flag=True
                   host.append(abc)
                if child.get("name")=="ServiceRi":
                   se1=child.text
                # this is for section 5.3.3
                test=child.text
                if test!=None:
                   if test.startswith("MPPSMF") : 
                        serv.append(service)
                        part.append(child.get("id"))
                        smf.append("MPPSMF")
                        #for sec 5.3.4
                        if service in temp1:
                           point1+=1
                           smf_list.append(service+"_P"+str(point1))
                        else:
                           smf_list.append(service+"_P0")
                        temp1.append(service)
                   elif test.startswith("PSMF"):
                        serv.append(service)
                        part.append(child.get("id"))
                        smf.append("PSMF")
                        #for sec 5.3.4
                        if service in temp2:
                           point2+=1
                           smf_list.append(service+"_P"+str(point2))
                        else:
                           smf_list.append(service+"_P0")
                        temp2.append(service)
             for line in xml.check_list.iterchildren():
                if line.tag=="total_check":
                   parti=line.text
             #section 5.3.3
             for i in range(len(serv)):
                sec5_3_3.append([serv[i],part[i],se1,smf[i]])
             #section 5.3.2
             listToStr = '; '.join(map(str, host))
             if flag:
                sec5_3.append([service,parti,se1,listToStr])
      #for sec 5.3.4
      smf_list.sort()
      strr = ' / '.join(map(str, smf_list))
      sec5_3_2=[]
      for server in servers:
         host=[]
         temp=[]
         flag=False
         for service in services:
            for file in \
                glob.glob('./result/services/{0}/*.xml'.format(service)):
                filenames = filenames + '\n' + file
                file_content = open(file, 'r')
                obj = 'obj' + str(count)
                obj = Annex_78(file)
                xml = obj.xml_obj
                point=0
                for child in xml.iterchildren():
                   # below are for section 5.3.2
                   abc3=child.text
                   if abc3!= None and abc3==server :
                      flag=True
                      if service in temp:
                         point+=1
                         ser=service+"_P"+str(point)
                         host.append(ser)
                      else: 
                         ser=service+"_P0"
                         host.append(ser)
                      temp.append(service)
                            
         listToStr = ' / '.join(map(str, host))
         if flag:
            sec5_3_2.append([server,listToStr])
      
      #section 5.1
      P8=Paragraph('''
                    <para align='center' fontSize=12><br /><b><a href="#reindex4"><a name="index4" />
                    5 APPLICATION ARCHITECTURE</a></b><br /></para>''',
                    styles["Normal"])
      P9=Paragraph('''
                    <para align='left' fontSize=12><br /><b>
                    5.1 HARDWARE ARCHITECTURE<br /></b></para>''',
                    styles["Normal"])
      P10=Paragraph('''
                    <para align='left' fontSize=10>
                    Note: These configurations are the last known of the platform<br /><br /></para>''',
                    styles["Normal"])
      data=[]
        
      data.append([Paragraph("Hostname", styleP),Paragraph("HostType", styleP),Paragraph("FunctionServer", styleP), \
                     Paragraph("cpu", styleP),Paragraph("CpuSpeed", styleP),Paragraph("sn", styleP),Paragraph("MemorySize", styleP),Paragraph("MachType", styleP)])
      for i in sec5_1:
         data.append(i)
      t8=Table(data, 1.0125*inch)
      t8.setStyle(TableStyle([
                  ('ALIGN', (0, 0), (-1,0), 'CENTER'),
                  ('ALIGN', (0, 1), (-1,-1), 'LEFT'),
                  ('FONTSIZE', (0, 0), (-1,-1), 10),
                  ('BOX', (0,0), (-1,-1), 0.25, colors.black),
                  ('INNERGRID', (0,0), (-1,-1), 0.25, colors.black),
                  ('BACKGROUND', (0, 0), (-1, 0), colors.lightskyblue)
                  ]))

      #section 5.2
      P11=Paragraph('''
                    <para align='left' fontSize=12><br /><b>
                    5.2 SOFTWARE CONFIGURATION<br /></b></para>''',
                    styles["Normal"])
      P12=Paragraph('''
                    <para align='left' fontSize=10>
                    Note: These configurations are the last known of the platform<br /><br /></para>''',
                    styles["Normal"])
      data=[]
      data.append([Paragraph("Hostname", styleP),Paragraph("OsLevel", styleP),Paragraph("OsType", styleP), \
                     Paragraph("Ss7StackVersion", styleP),Paragraph("OracleVersion", styleP),Paragraph("OspWeekLevel", styleP)])
      for i in sec5_2:
         data.append(i)
      t9=Table(data, 1.35*inch)
      t9.setStyle(TableStyle([
                  ('ALIGN', (0, 0), (-1,0), 'CENTER'),
                  ('ALIGN', (0, 1), (-1,-1), 'LEFT'),
                  ('FONTSIZE', (0, 0), (-1,-1), 10),
                  ('BOX', (0,0), (-1,-1), 0.25, colors.black),
                  ('INNERGRID', (0,0), (-1,-1), 0.25, colors.black),
                  ('BACKGROUND', (0, 0), (-1, 0), colors.lightskyblue)
                  ]))
      #section 5.3.1
      P13=Paragraph('''
                    <para align='left' fontSize=12><br /><b><a href="#reindex4.1"><a name="index4.1" />
                    5.3 SERVICES CONFIGURATION</a></b><br /><br /></para>''',
                    styles["Normal"])
      P14=Paragraph('''
                    <para align='left' fontSize=10>
                    5.3.1 Servers hosting each SLEE Partition<br />
                    Note: These configurations are the last known of the platform<br /><br /></para>''',
                    styles["Normal"])
      data=[]
      data.append([Paragraph("Service", styleP),Paragraph("Partition", styleP),Paragraph("RI", styleP),Paragraph("Hosts_list", styleP)])
      sec5_3.sort()
      for i in sec5_3:
         l1=Paragraph(i[0], styleP)
         l2=Paragraph(i[1], styleP)
         l3=Paragraph(i[2], styleP)
         l4=Paragraph(i[3], styleP)
         data.append([l1,l2,l3,l4])
      t10=Table(data, 2.025*inch)# 3.25*inch)
      t10.setStyle(TableStyle([
                    ('ALIGN', (0, 0), (-1,0), 'CENTER'),
                    ('ALIGN', (0, 1), (-1,-1), 'LEFT'),
                    ('FONTSIZE', (0, 0), (-1,-1), 10),
                    ('BOX', (0,0), (-1,-1), 0.25, colors.black),
                    ('INNERGRID', (0,0), (-1,-1), 0.25, colors.black),
                    ('BACKGROUND', (0, 0), (-1, 0), colors.lightskyblue)
                    ]))
      #section- 5.3.2
        
      P15 = Paragraph('''
                    <para align=left fontSize=10><br />
                    5.3.2 SLEE partitions hosted by each server<br />
                    Note: These configurations are the last known of the platform
                    <br /><br /></para>''',
                    styles["Normal"])
        
      data = []
      data.append([Paragraph('Host', styleP), Paragraph('SLEE_partitions_list', styleP)])
      sec5_3_2.sort()
      for i in sec5_3_2:
         co1 = Paragraph(i[0], styleP)
         co2 = Paragraph(i[1], styleP)
         data.append([co1,co2])
      t11 = Table(data, 4.05 * inch)
      t11.setStyle(TableStyle([
                    ('ALIGN', (0, 0), (-1, 0), 'CENTER'),
                    ('ALIGN', (0, 1), (-1, -1), 'LEFT'),
                    ('BOX', (0, 0), (-1, -1), 0.5, colors.black),
                    ('FONTSIZE', (0, 0), (-1, -1), 10),
                    ('GRID', (0, 0), (2, -1), 0.5, colors.black),
                    ('BACKGROUND', (0, 0), (-1, 0), colors.lightskyblue),
                    ]))

      #section 5.3.3 
      P16=Paragraph('''
                    <para align='left' fontSize=10><br />
                    5.3.3 SMFs hosting each SMF partition<br />
                    Note: These configurations are the last known of the platform
                    <br /><br /></para>''',
                    styles["Normal"])
      data=[]
      data.append([Paragraph("Service", styleP),Paragraph("Partition", styleP),Paragraph("RI", styleP),Paragraph("SMF_Names_list", styleP)])
      sec5_3_3.sort()
      for i in sec5_3_3:
         l1=Paragraph(i[0], styleP)
         l2=Paragraph(i[1], styleP)
         l3=Paragraph(i[2], styleP)
         l4=Paragraph(i[3], styleP)
         data.append([l1,l2,l3,l4])
      t12=Table(data, 2.025*inch)
      t12.setStyle(TableStyle([
                    ('ALIGN', (0, 0), (-1,0), 'CENTER'),
                    ('ALIGN', (0, 1), (-1,-1), 'LEFT'),
                    ('FONTSIZE', (0, 0), (-1,-1), 10),
                    ('BOX', (0,0), (-1,-1), 0.25, colors.black),
                    ('INNERGRID', (0,0), (-1,-1), 0.25, colors.black),
                    ('BACKGROUND', (0, 0), (-1, 0), colors.lightskyblue)
                    ]))
      #section 5.3.4
      P17=Paragraph('''
                    <para align='left' fontSize=10><br />
                    5.3.4 SMF parttions hosting by each SMF<br />
                    Note: These configurations are the last known of the platform
                    <br /><br /></para>''',
                    styles["Normal"])
      data=[]
      data.append([Paragraph("SMF_Name", styleP),Paragraph("SMF_partitions_list", styleP)])
      if len(strr)!=0 :
         data.append([Paragraph("MPPSMF", styleP),Paragraph(strr, styleP)])
      t13=Table(data, 4.05*inch)# 3.25*inch)
      t13.setStyle(TableStyle([
                    ('ALIGN', (0, 0), (-1,0), 'CENTER'),
                    ('ALIGN', (0, 1), (-1,-1), 'LEFT'),
                    ('VALIGN', (0, 1), (-1,-1), 'TOP'),
                    ('FONTSIZE', (0, 0), (-1,-1), 10),
                    ('BOX', (0,0), (-1,-1), 0.25, colors.black),
                    ('INNERGRID', (0,0), (-1,-1), 0.25, colors.black),
                    ('BACKGROUND', (0, 0), (-1, 0), colors.lightskyblue)
                    ]))
        
      #section 5.4 and section 6
      P18=Paragraph('''
                    <para align='center' fontSize=12><br /><b>
                    5.4 APPLICATION ARCHITECTURE CONCLUSION
                    </b><br /></para>''',
                    styles["Normal"])
      P19=Paragraph('''
                    <para align='center' fontSize=12><br /><b><a href="#reindex5"><a name="index5" />
                    6. GENERAL ALANIS CONCLUSION
                    </a></b><br /></para>''',
                    styles["Normal"])
      P20=Paragraph('''<para align='left' fontSize=10 color="red"><br /><b>
                    TO BE COMPLETED
                    </b><br /></para>''',
                    styles["Normal"])

      tempy.append(P8)
      tempy.append(P9)
      tempy.append(P10)
      tempy.append(t8)
      tempy.append(P11)
      tempy.append(P12)
      tempy.append(t9)
      #section 5.3.1
      tempy.append(PageBreak())
      tempy.append(P13)
      tempy.append(P14)
      tempy.append(t10)
      #sec 5.3.2
      tempy.append(P15)
      tempy.append(t11)
      tempy.append(PageBreak())
      #sec 5.3.3
      tempy.append(P16)
      tempy.append(t12)
        
      #sec 5.3.4
      tempy.append(P17)
      tempy.append(t13)
      #sec 5.4 and sec 6
      tempy.append(P18)
      tempy.append(P20)
      tempy.append(PageBreak())
      tempy.append(P19)
      tempy.append(P20)
      tempy.append(PageBreak())
      return tempy

class Annex_78(object):
    '''proceesing data for annexure 7, 8 of sercvers and section 5 services '''
    def __init__(self, xml_file):
        self.xml_file = xml_file
        self.xml_obj = self.getXMLObject()
        
    def fetch_Data(self,testarg):
        '''fetch the data and form tables for both inc , warning tests of servers , adds hyperlinking, services'''
        global x
        global img
        global tt1
        global tt2
        global tempp
        global tempp1
        data = []
        data5=[]
        (width, self.height) = letter
        styles = getSampleStyleSheet()
        xml = self.xml_obj
        img=False
        if xml.get('status')==testarg : 
            no_comt = xml.findall('comment') 
            an1=len(no_comt)
            index=0
            while an1!=0:
                data = []
                data5 = []
                an1=an1-1
                xml.comment=no_comt[index]
                index=index+1
                x+=1
                crity = xml.get('criticity')
                kbref=" "
                for i in kbr:
                   search=i.lower().find(testname.lower())
                   if search!=-1:
                      kbref=i.split()[0]
                      break
                cc.append(str(x)+testname+" "+server_name)
                tst=" "
                if testarg=="WG":
                   tst="Warning_TestName"
                   dic.append([testname,crity,kbref,server_name])
                   #below are for inner linking of document
                   val="link"+str(tt1)
                   if testname not in testn1:
                       tempp1.append([testname, val+str(1)]) 
                       data.append([Paragraph('<para color=blue> <a name=%s /><u><a href=%s>%s</a></u></para>'%(val, "#"+val+str(1), tst),styleP), 'ServerName', 'RunDate', 'KbRef',
                                'ReturnCode'])
                       tt1=tt1+1
                   else:
                       for i in tempp1:
                           if i[0]==testname:
                               te=i[1]
                       data.append([Paragraph('<para color=blue><u><a href=%s>%s</a></u></para>'%("#"+te,tst),styleP), 'ServerName', 'RunDate', 'KbRef',
                                'ReturnCode'])
                   testn1.append(testname)
                elif testarg=="INC":
                   tst="Inc_TestName"
                   dic1.append([testname,crity,kbref,server_name])
                   #for section 2.4
                   desc = '%s' % xml.description
                   section2_4.append([testname,desc])
                
                   val="link"+str(tt1)
                   if testname not in testn:
                       tempp.append([testname, val+str(1)]) 
                       data.append([Paragraph('<para color=blue> <a name=%s /><u><a href=%s>%s</a></u></para>'%(val, "#"+val+str(1),tst),styleP), 'ServerName', 'RunDate', 'KbRef',
                                'ReturnCode'])
                       tt1=tt1+1
                   else:
                       for i in tempp:
                           if i[0]==testname:
                               te=i[1]
                       data.append([Paragraph('<para color=blue><u><a href=%s>%s</a></u></para>'%("#"+te,tst),styleP), 'ServerName', 'RunDate', 'KbRef',
                                'ReturnCode'])
                   testn.append(testname)
                code = xml.get('return_code')
                data.append([Paragraph(testname,styleP), server_name, rundate, kbref, code])
                data5.append(['CommandResult'])
                ab = xml.find('result')
                if ab != None:
                    cmd_rsl = 0
                    if xml.result.countchildren() != 0:
                        xmlc=0
                        noo=[]
                        flag=True
                        for line in xml.result.iterchildren():
                            temp=" ".join(str(line).split())
                            xmlc+=len(temp)
                            if xmlc>500:
                                temp=temp[:500-(xmlc-len(temp))]
                                data5.append([Paragraph(temp,styleP)])
                                cmd_rsl += 1
                                break
                            else:
                                noo.append(temp)
                                if temp!="":
                                    data5.append([Paragraph(temp,styleP)])
                                    cmd_rsl += 1
                        for i in noo:
                            if i!='':
                                flag=False
                                break
                        if flag:
                            data5.append([' '])
                            cmd_rsl += 1
                    else:
                        cmd_rsl = 1
                        data5.append([' '])
                else:
                    cmd_rsl = 1
                    data5.append([' '])
                data5.append(['Comments'])
                ab = xml.find('comment')
                if ab != None:
                    cmnt = 0
                    if xml.comment.countchildren() != 0:
                        for line in xml.comment.iterchildren():
                            temp=" ".join(str(line).split())
                            data5.append([Paragraph(temp,styleP)])
                            cmnt += 1
                    else:
                        cmnt = 1
                        data5.append([' '])
                else:
                    cmnt = 1
                    data5.append([' '])
                data5.append(['First 500 characters are displayed for CommandResult . See full annexe if necessary'])
                data5.append([' '])
               
                t = Table(data, 1.62 * inch)
                t.setStyle(TableStyle([
                    ('ALIGN', (0, 0), (-1, 1), 'CENTER'),
                    ('BOX', (0, 0), (-1, -1), 0.5, colors.black),
                    ('FONTSIZE', (0, 0), (-1, -1), 10),
                    ('GRID', (0, 0), (4, 1), 0.5, colors.black),
                    ('BACKGROUND', (0, 0), (-1, 0), colors.lightskyblue),
                    ]))

                t1 = Table(data5, 8.1 * inch)
                t1.setStyle(TableStyle([
                    ('ALIGN', (0, 0), (-1, 0), 'CENTER'),
                    ('BOX', (0, 0), (-1, -1), 0.5, colors.black),
                    ('FONTSIZE', (0, 0), (-1, -1), 10),
                    ('BACKGROUND', (0, 0), (-1, 0), colors.lightskyblue),
                    ('LINEABOVE', (0, 1), (-1, 1), 0.5, colors.black), 
                    ('LINEABOVE', (0, 1 + cmd_rsl), (-1, 1 + cmd_rsl), 0.5,
                     colors.black), 
                    ('LINEABOVE', (0, 1 + cmd_rsl + 1), (-1, 1 + cmd_rsl
                     +1), 0.5, colors.black), 
                    ('BACKGROUND', (0, 1 + cmd_rsl), (-1, 1 + cmd_rsl),
                     colors.lightskyblue),
                    ('ALIGN', (0, 1 + cmd_rsl), (-1, 1 + cmd_rsl), 'CENTER'),   
                    ('LINEABOVE', (0, 2 + cmd_rsl+cmnt), (-1, 2 + cmd_rsl+cmnt), 0.5,
                     colors.black),
                    ('LINEABOVE', (0, 2 + cmd_rsl + cmnt + 1), (-1, 2 + cmd_rsl
                     + cmnt + 1), 0.5, colors.black),
                    ('TEXTCOLOR', (0, 2 + cmd_rsl + cmnt), (-1, 2 + cmd_rsl
                     + cmnt), colors.red)
                    ]))

                elements.append(t)
                elements.append(t1)
                an2 = xml.findall('result')
                if len(an2)==1:
                    xml.result=None
        else:
            if testarg=="INC":
                self.third_part()
          
    def third_part(self):
        ''' fetching the datas for alanis os ckeck ok i.e section 2.3 '''
        xml = self.xml_obj
        if xml.get('status')=="OK" : 
            if  xml.description in dict_third_part.keys():
                dict_third_part[xml.description].append(server_name)
            else:
                dict_third_part[xml.description] = [server_name]
    # ----------------------------------------------------------------------

    def getXMLObject(self):
        ''' parsing the xml to file to able to access all its tags and attribute and its values,
            adding the adding the missed ending comment tag and removing the non-printable ascii charcater TAB'''
        with open(self.xml_file) as f:
            xml2= f.readlines()
            cont=0
            lmr=""
            i=0
            while i!=len(xml2):
                if (xml2[i].strip()).startswith("<comment"):
                    j=i+1
                    while j!=len(xml2):
                        if (xml2[j].strip()).startswith("<comment"):
                            if (xml2[j-1].strip()).startswith("</comment>"):
                                i=j
                                break
                            else:
                                xml2[j-1]=xml2[j-1]+"\n</comment>"
                                i=j
                                break
                                
                        elif (xml2[j].strip()).startswith("</comment>"):
                            i=j
                            break
                        elif (xml2[j].strip()).startswith("<result"):
                            xml2[j-1]=xml2[j-1]+"\n</comment>"
                            i=j
                            break
                        
                        j+=1
                i+=1
            listToStr5 = ''.join(map(str, xml2))
            xml1=''.join([c for c in listToStr5 if ord(c) > 31 or ord(c) == 9])
        return objectify.fromstring(xml1.encode('utf-8'))


def main():
   """ main function i.e the program excution starts from here"""
   
   global elements
   global fn
   global pfname
   global last_modified
   global server_name
   global testname
   global rundate

   #ff=Fetch_File()
   getfile()
   #print("<p>fn is %s </p>"%fn)
   #fn="./alanis_result_default_20190220_081106.tgz"
   
   # deleting the already existing result directory
   lsfiles1=os.listdir()
   for i in lsfiles1:
      if i == "result" :
         shutil.rmtree(i)  
   tf = tarfile.open(fn)
   tf.extractall()
   tf.close()
   
   #local variables
   filenames = ''
   count = 0

   # fetching data for annexture 7 and 8 
   tree = ET.parse('./result/servers/alanisOspPlatform.xml')
   root = tree.getroot()
   for child in root:
      servers.append(child.text)
   testcase=["INC","WG"]
   for i in testcase:
      for server in servers:
         for file in \
            glob.glob('./result/servers/{0}/xml/*.xml'.format(server)):
            filenames = filenames + '\n' + file
            last_modified = time.ctime(os.path.getmtime(file)).split(' ')
            server_name = file.split('/')[3]
            testname = file.rsplit('\\', 1)[1].replace('.pl.xml', '')
            rundate = last_modified[1] + ' ' + last_modified[2] + ', ' \
            + last_modified[4] + ' ' + last_modified[3].rsplit(':',1)[0]
            file_content = open(file, 'r')
            xml = './result/servers/{0}/xml/{1}'.format(server, file.split('\\')[1])
            obj = 'obj' + str(count)
            obj = Annex_78(xml)
            obj.fetch_Data(i)
            count = count + 1
      
      if i== "INC":
         elements.append(PageBreak())
         elements.append(Paragraph('''<para align='center' fontSize=12><br /><b><a href="#reindex7"><a name="index7" />8 ANNEXE 2 (WARNING TESTS)</a></b><br /><br /></para>''',styles["Normal"]))
         elements.append(Paragraph('''<para align='left' fontSize=10>This chapter provides detail of each WARNING Test<br /><br /></para>''',styles["Normal"]))
   
   '''framing the pdf'''
   ims=Img2Sec_6()
   
   ele=ims.img2intro()+ims.sec2_24()+ims.sec_3()
   ele.append(PageBreak())
   ele=ele+ims.sec4_43()
   ele.append(PageBreak())
   ele=ele+ims.sec5_54_6()
   ele.append(Paragraph('''<para align='center' fontSize=12><br /><b><a href="#reindex6"><a name="index6" />7 ANNEXE 1 (INC TESTS)</a></b><br /><br /></para>''',styles["Normal"]))
   ele.append(Paragraph('''<para align='left' fontSize=10>This chapter provides detail of each INC Test<br /><br /></para>''',styles["Normal"]))
   elements=ele+elements

  
   pdf=fn[:-4]+".pdf"
        
  
   canvas1 = SimpleDocTemplate( 
         pdf,
         pagesize=letter,
         rightMargin=10,
         leftMargin=10,
         topMargin=30,
         bottomMargin=30,
         )
        
   now = datetime.now()
   h24=now.strftime("%H")
   if int(h24) < 12 :
      period="AM IST"
   else:
      period="PM IST"
       
   
   def myFirstPage(canvas, canvas1):
      canvas.saveState()
      canvas.setFont('Times-Roman',10)
      
      canvas.drawString(15, 25, "%s %s" % (now.strftime("%b %d, %Y %I:%M "),period))# %I 12 hour format P for pm
      canvas.restoreState()
          
   def myLaterPages(canvas, canvas1):
      canvas.saveState()
      canvas.setFont('Times-Roman',10)
      canvas.drawString(15, 25, "%s %s" % (now.strftime("%b %d, %Y %I:%M "),period))# %I 12 hour format P for pm
      canvas.restoreState()
   canvas1.build(elements,onFirstPage=myFirstPage,onLaterPages=myLaterPages)
   
   with open(pdf,'rb') as f:
      pdfobj=PdfFileReader(f)
      nop=pdfobj.getNumPages()
      
      for i in range(nop):
         page=pdfobj.getPage(i)
         text=page.extractText()
         t=text.find("This chapter provides detail of each INC Test")
         if t!=-1:
            pagebk=i
            break
      
   packet = io.BytesIO()
   
   can = canvas.Canvas(packet, pagesize=letter)
  
   for i in range(nop):
      if i>=pagebk:
         
         can.rect(14, 35, 584, 721, stroke=1, fill=0)
         can.showPage()
      else:
         can.showPage()
   can.save()

   #move to the beginning of the StringIO buffer
   packet.seek(0)
   new_pdf = PdfFileReader(packet)
   # read your existing PDF
   pdf_object=open(pdf, "rb")
   existing_pdf = PdfFileReader(pdf_object)
   output = PdfFileWriter()
   
   for i in range(nop):
      page = existing_pdf.getPage(i)
      page.mergePage(new_pdf.getPage(i))
      output.addPage(page)
   
   pdf1=fn[:-4]+"updated.pdf"

   
   outputStream = open('D:/Alanis_Tool_Reports/generated_pdfs/'+pdf1, "wb")
   output.write(outputStream)
   outputStream.close()
   pdf_object.close()
   os.remove(pdf)
   #f=open(pdf1,'rb')
   #open('C:/Apache2/htdocs/' + pdf1, 'wb').write(f.read()) or use shutil.move to htdocs
   
   #print("<br /><br /><p align=center><a href=%s>download converted file</a></p>"%('http://10.203.28.245:8052/'+pdf1))
   print("<form enctype = %s method='post' action=%s align='center'>"%("multipart/form-data",('http://10.203.28.211:8052/'+pdf1)))
   print("<br /><input type='submit' value='Download the PDF file' />")
   print("</form")
   print("<br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><p align=center><font size=10><a href = 'http://http://10.203.28.211:8052//code_files/logout.php' tite = 'Logout'>logOut.</font></p>")
   print("</body></html>")

   
# ----------------------------------------------------------------------

if __name__ == '__main__':
   main()
   
   

       




